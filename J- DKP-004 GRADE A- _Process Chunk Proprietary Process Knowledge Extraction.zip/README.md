
  # J- DKP-004 GRADE A- _Process Chunk Proprietary Process Knowledge Extraction

  This is a code bundle for J- DKP-004 GRADE A- _Process Chunk Proprietary Process Knowledge Extraction. The original project is available at https://www.figma.com/design/T76sBXgrGyuSoDMRSRidwp/J--DKP-004-GRADE-A--_Process-Chunk-Proprietary-Process-Knowledge-Extraction.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  